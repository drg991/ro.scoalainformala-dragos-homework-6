package biathlon;

import java.util.Collections;
import java.util.List;

public class BiathlonApp {
    public static void main(String[] args) {
        String csv = """
            11,Umar Jorgson,SK,30:27,xxxox,xxxxx,xxoxo
            1,Jimmy Smiles,UK,29:15,xxoox,xooxo,xxxxo
            27,Piotr Smitzer,CZ,30:10,xxxxx,xxxxx,xxxxx
        """;

        List<Athlete> athletes = BiathlonParser.parse(csv);
        Collections.sort(athletes);

        System.out.println("Winner - " + athletes.get(0));
        System.out.println("Runner-up - " + athletes.get(1));
        System.out.println("Third Place - " + athletes.get(2));
    }
}
