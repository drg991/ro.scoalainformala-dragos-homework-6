package biathlon;

enum ShootingRange {
    FIRST,
    SECOND,
    THIRD
}
