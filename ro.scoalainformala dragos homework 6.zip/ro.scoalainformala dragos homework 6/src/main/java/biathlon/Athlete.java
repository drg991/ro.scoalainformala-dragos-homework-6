package biathlon;

import java.util.Arrays;

class Athlete implements Comparable<Athlete> {
    private final int number;
    private final String name;
    private final String country;
    private final String skiTime;
    private final String[] shootings;
    private final int penaltySeconds;
    private final int totalSeconds;

    public Athlete(int number, String name, String country, String skiTime, String... shootings) {
        this.number = number;
        this.name = name;
        this.country = country;
        this.skiTime = skiTime;
        this.shootings = shootings;
        this.penaltySeconds = calculatePenalty();
        this.totalSeconds = timeToSeconds(skiTime) + penaltySeconds;
    }

    private int calculatePenalty() {
        return Arrays.stream(shootings)
                     .mapToInt(range -> (int) range.chars().filter(c -> c == 'o').count() * 10)
                     .sum();
    }

    private int timeToSeconds(String time) {
        String[] parts = time.split(":");
        return Integer.parseInt(parts[0]) * 60 + Integer.parseInt(parts[1]);
    }

    public String getFormattedTotalTime() {
        int minutes = totalSeconds / 60;
        int seconds = totalSeconds % 60;
        return String.format("%02d:%02d", minutes, seconds);
    }

    @Override
    public int compareTo(Athlete other) {
        return Integer.compare(this.totalSeconds, other.totalSeconds);
    }

    @Override
    public String toString() {
        return String.format("%s %s (%s + %d)", name, getFormattedTotalTime(), skiTime, penaltySeconds);
    }
}
