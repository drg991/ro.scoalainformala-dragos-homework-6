package biathlon;

import java.util.ArrayList;
import java.util.List;

class BiathlonParser {
    public static List<Athlete> parse(String csvContent) {
        List<Athlete> athletes = new ArrayList<>();
        String[] lines = csvContent.strip().split("\n");
        for (String line : lines) {
            String[] parts = line.split(",");
            int number = Integer.parseInt(parts[0]);
            String name = parts[1];
            String country = parts[2];
            String skiTime = parts[3];
            String shooting1 = parts[4];
            String shooting2 = parts[5];
            String shooting3 = parts[6];
            athletes.add(new Athlete(number, name, country, skiTime, shooting1, shooting2, shooting3));
        }
        return athletes;
    }
}
